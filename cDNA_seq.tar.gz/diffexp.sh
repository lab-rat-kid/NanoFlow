#			  		        **IMPORTANT**						
#												
#	Required installs are listed in environment.yaml, and installed in cDNA_DE env		
#												
#	Required Inputs in RawData:								
#		- demultiplexed, trimmed, and concatenated .fastq files		
#	Required Inputs in ReferenceData:							
#		- transcriptome .fa file (if only have genome .fa file, see hashed gffread command)		
#		- gene annotation .gff or .gtf file						
#	Required Changes:									
#		- edit the .fa and .gtf file names in the below commands accordingly			
#		- edit the config.yaml file with the .fastq file names in RawData and groups	
#		- edit the config.yaml file with the .fa and .gft names in ReferenceData	
#
#	-t, -p, and -@ options in commands below are for the number threads to use, currently set to 12		
#												
#	All files generated are named according to the original fastq files in the RawData folder		



# Unhash if you don't have a transcript.fa file, but do have a genomic.fa file and an annotation.gff/.gtf file, create one with the command below
#gffread -F -w transcript.fa -g genome.fa annotation.gtf

### Unhash if reads have not been demultiplexed, and then remove any fastq not for your debarcoded data. 
#porechop -i path/to/fastq -b ./RawData/ -t12

### Unhash if reads have not had adaptors removed, or if ends need trimming for another reason.
#mkdir RawData/temp
#for infile in ./RawData/*.fastq
#do
#base=$(basename ${infile} .fastq)
#porechop -i ${infile} -o ./RawData/temp/${base}.fastq --extra_end_trim 20 -t 12
#rm ${infile}
#done
#mv ./RawData/temp/* ./RawData/
#rm -r ./RawData/temp

### Unhash to filter for quality and length
#mkdir RawData/temp
#for infile in ./RawData/*.fastq
#do
#base=$(basename ${infile} .fastq)
#filtlong --min_length 50 --target_bases 5000000000000 --mean_q_weight 10 ${infile} > ./RawData/temp/${base}.fastq
#rm ${infile}
#done
#mv ./RawData/temp/* ./RawData/
#rm -r ./RawData/temp


### Main loop ###

### hash if you already have an index file
minimap2 -t 12 -I 1000G -d ./ReferenceData/transcript.mmi ./ReferenceData/oviAri4.transcript.fa

mkdir Analysis/
mkdir Analysis/Minimap/
mkdir Analysis/samtools/
mkdir Analysis/Salmon/
mkdir Analysis/Results/

for infile in ./RawData/*.fastq
do
base=$(basename ${infile} .fastq)
minimap2 -t 12 -ax map-ont -p 1.0 -N 100 ./ReferenceData/transcript.mmi ${infile} | samtools view -Sb > ./Analysis/Minimap/raw${base}.bam
samtools sort ./Analysis/Minimap/raw${base}.bam -o ./Analysis/Minimap/${base}.bam -@ 12
rm ./Analysis/Minimap/raw${base}.bam
samtools index ./Analysis/Minimap/${base}.bam
samtools flagstat ./Analysis/Minimap/${base}.bam > ./Analysis/samtools/${base}.flagstat
salmon quant --noErrorModel -p 12 -t ./ReferenceData/oviAri4.transcript.fa -g ./ReferenceData/oviAri4.ncbiRefSeq.gtf -l SF -a ./Analysis/Minimap/${base}.bam -o ./Analysis/Salmon/${base}
done

R --slave -e 'rmarkdown::render("cDNA_DE_QC_Report.Rmd", "html_document")'
R --slave -e 'rmarkdown::render("cDNA_DE_Report.Rmd", "html_document")'
