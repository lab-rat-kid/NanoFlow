# We need a few bits of information here:

# name of control group
Control <- c("Control")
# FDR threshold to use
FDR <- 0.05 
# Your GOIs here...must be official gene_ID
GenesOfInterest <- c("A1BG","AACS","ZNRF3","ZP2") 
# if you have changed the dir for this then you will have to
# specify where /Analysis/Results/cDNA_DE_Report.Rdata file is
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
datafile <- paste0(
  dirname(rstudioapi::getActiveDocumentContext()$path),
  "/Analysis/Results/NanoFlow_Report.Rdata")


## imports, etc 
library(grid)
library(gridExtra)
library(pcaMethods)
library(yaml)
library(DRIMSeq)
library(AnnotationDbi)
library(GenomicFeatures)
library(dplyr)
library(edgeR)
library(DEXSeq)
library(devtools)
library(ggplot2)
library(ggforce)
library(tidyr)
library(reshape2)
library(session)     
library(writexl)
library(digest)
library(kableExtra)
library(stageR)
library(ShortRead)
library(tidyverse)


## Get counts, model, and fit
# Get Rmd file from previous analysis
tmp.env <- new.env() # create a temporary environment
load(datafile, envir=tmp.env) # load workspace into temporary environment
gene_cts <- tmp.env[["gene_cts"]] # get the objects you need into your globalenv()
studyDesign <- tmp.env[["studyDesign"]] # get the objects you need into your globalenv()
#x <- get("x", pos=tmp.env) # equivalent to previous line
#x <- tmp.env$x # equivalent to previous line
rm(tmp.env) # remove the temporary environment to free up memory
rm(datafile)

## Fit to model and test
studyDesign$group <- fct_relevel(studyDesign$group, Control)
Group <- factor(studyDesign$group)
design <- model.matrix(~Group)
y <- DGEList(gene_cts)
y <- calcNormFactors(y)
y <- estimateDisp(y,design)
fit <- glmQLFit(y,design)

# change coef to the range of groups to compare to control
numberofgroups <- length(unique(studyDesign$group))
if(numberofgroups == 2){qlf <<- glmQLFTest(fit)
}else{qlf <<- glmQLFTest(fit, coef = 2:numberofgroups)}

# if you want to specify which groups to compare, use this below
# change coef to a range, or specific values
# qlf <- glmQLFTest(fit, coef = 2:3)


topTags <-topTags(qlf, n=nrow(y), sort.by="PValue")[[1]]
DEGlist <- topTags[which(topTags$FDR<=FDR),]

norm_counts <- cpm(y) # to plot against
GOIdata <- t(norm_counts[which(row.names(norm_counts)%in%GenesOfInterest),])

## write a CSV for your GOI DEG data
GOI.DEGs <- DEGlist[which(row.names(DEGlist)%in%GenesOfInterest),]
GOI.DEGs <- GOI.DEGs[,-2:-3]
GOI.DEGs$Gene <- rownames(GOI.DEGs)
GOI.DEGs <- GOI.DEGs[,c(4,1:3)]
colnames(GOI.DEGs) <- c("Gene","Log2FC","P-Value","FDR")

write.csv(as.data.frame(GOI.DEGs), 
          file = "my GOI DEG data.csv", 
          row.names = F)

## plot GOI data

rownames(GOIdata) <- as.character(row.names(studyDesign))
GOIdata <- as.data.frame(GOIdata)
GOIdata$group <- studyDesign$group
GOIdata$sample <- as.character(row.names(GOIdata))
GOIdatamelt <- melt(GOIdata, id.vars=c("sample", "group"), 
                    variable.name="gene")

GOI_plot <- ggplot(data = GOIdatamelt, aes(y=value, x=group, fill=group)) +
  geom_boxplot() + 
  stat_boxplot(geom ='errorbar', width = 0.4) +
  geom_point(pch = 1, size = 4, colour = 'black', alpha = 0.5) +
  stat_summary(
    geom = "point",
    fun = "mean",
    col = "black",
    size = 2.5,
    pch =24,
    fill = "red") +
  xlab("") +ylab("Norm Read Count") +
  ggtitle("Normalised Count Data for GOIs")+
  theme_bw() +
  theme(text = element_text(size=15),  
        plot.title = element_text(size=15, hjust = 0.5), 
        axis.text.x = element_text(size=10), 
        axis.text.y = element_text(size=8))

GOI_facet <- GOI_plot + 
  facet_wrap(gene~., scales="free_y") +
  theme(strip.text.x = element_text(size = 6))

GOI_facet

